# Converted from Google Apps Script to Python

import re
import logging
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.service_account import Credentials

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Define the source folder ID and scopes
CSV_FILES = "1t4d_8lMC3ZJfSyainbpwInoDta7n69hC"
SCOPES = ["https://www.googleapis.com/auth/drive"]


def normalize_filenames_in_source():
    creds = Credentials.from_service_account_file("credentials.json", scopes=SCOPES)
    service = build("drive", "v3", credentials=creds)

    renamed = 0
    skipped = 0
    date_pattern = re.compile(r"\d{4}-\d{2}-\d{2}")

    try:
        # Get all files in the folder
        results = (
            service.files()
            .list(
                q=f"'{CSV_FILES}' in parents and trashed = false",
                fields="files(id, name)",
                supportsAllDrives=True,
                includeItemsFromAllDrives=True
            )
            .execute()
        )
        files = results.get("files", [])
        logging.debug(f"🔍 Found {len(files)} files in folder '{CSV_FILES}'")

        for file in files:
            original_name = file["name"].strip()
            logging.debug(f"📄 Checking file: {original_name}")
            match = date_pattern.search(original_name)

            if not match:
                logging.debug(f"⏭️ Skipping file (no date found): {original_name}")
                skipped += 1
                continue

            index = original_name.find(match.group(0))
            normalized_name = original_name[index:].strip()

            if normalized_name != original_name:
                try:
                    # Copy the file with the new name
                    copied_file = service.files().copy(
                        fileId=file['id'],
                        body={'name': normalized_name, 'parents': [CSV_FILES]},
                        supportsAllDrives=True
                    ).execute()
                    logging.info(f"📄 Copied: {original_name} → {normalized_name}")

                    # Delete the original file
                    service.files().delete(
                        fileId=file['id'],
                        supportsAllDrives=True
                    ).execute()
                    logging.info(f"🗑️ Deleted original: {original_name}")
                    renamed += 1
                except HttpError as error:
                    logging.warning(f"⚠️ Failed to copy/delete \"{original_name}\": {error}")
                    logging.debug(f"❌ HttpError detail: {error}")
            else:
                skipped += 1

    except HttpError as error:
        logging.error(f"❌ API error occurred: {error}")

    logging.debug(f"📊 Processed {len(files)} files total")
    logging.info(f"✅ Normalization complete. Renamed: {renamed}, Skipped: {skipped}")


if __name__ == "__main__":
    normalize_filenames_in_source()
